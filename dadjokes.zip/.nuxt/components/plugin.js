import Vue from 'vue'
import { wrapFunctional } from './index'

const components = {
  Header: () => import('../..\\components\\Header.vue' /* webpackChunkName: "components/header" */).then(c => wrapFunctional(c.default || c)),
  Joke: () => import('../..\\components\\joke.vue' /* webpackChunkName: "components/joke" */).then(c => wrapFunctional(c.default || c)),
  SearchJokes: () => import('../..\\components\\SearchJokes.vue' /* webpackChunkName: "components/search-jokes" */).then(c => wrapFunctional(c.default || c))
}

for (const name in components) {
  Vue.component(name, components[name])
  Vue.component('Lazy' + name, components[name])
}
