<template>
  <div>
    <Header></Header>
    <Nuxt />
  </div>
</template>

<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  background-color: #f8f9fa;
}
</style>
