export const state = () => ({
    config: {
        headers: {
            Accept: 'application/json'
        }
    }
})


export const actions = {
    
}

export const mutations = {

}